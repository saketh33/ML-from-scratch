# Machine Learning from Scratch
This is the code repository for my [Machine Learning from Scratch youtube playlist](https://www.youtube.com/watch?v=4PHI11lX11I&list=PLP3ANEJKF1TzOz3hwOoRclgRFVi8A76k2)
## 01 Linear Regression using Least Squares  
[Check out the tutorial video](https://www.youtube.com/watch?v=kR6tBAq16ng&t=2s)
## 02 Linear Regression using Gradient Descent  
[Check out the tutorial video](https://www.youtube.com/watch?v=4PHI11lX11I&t=2s)
[Check out the medium post](https://towardsdatascience.com/linear-regression-using-gradient-descent-97a6c8700931)
## 03 Linear Regression in 2 minutes
[Check out the medium post](https://towardsdatascience.com/linear-regression-in-6-lines-of-python-5e1d0cd05b8d)
